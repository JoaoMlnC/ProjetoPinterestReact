# Pinterest

Libs que eu utilizei

// usando npm

npm install @mui/icons-material

npm install @mui/material @mui/styled-engine-sc styled-components

npm install @mui/material @emotion/react @emotion/styled

npm install styled-components

npm install --save material-ui-popup-state
